package Pingouin;

public interface ArbitreInterface {
    public Object arbitreMatch();
}
